﻿StreamReader file = new("D:\\2022czerwiec\\2022czerwiec\\przyklad.txt");
List<string> liczbyZpliku = new();
string? liczbaZpliku;

while ((liczbaZpliku = file.ReadLine()) != null)
{
    liczbyZpliku.Add(liczbaZpliku);
}
file.Close();

Console.WriteLine("zadanie 4.0");

foreach (var item in liczbyZpliku)
{
    int liczba = int.Parse(item); 
    int ostatniaCyfra;
    int odbicie = 0;
    while (liczba > 0)
    {
        ostatniaCyfra = liczba % 10;
        odbicie = odbicie * 10 + ostatniaCyfra;

        liczba /= 10;
    }
    Console.WriteLine(odbicie);
}

Console.WriteLine("zadanie 4.1");

foreach (var item in liczbyZpliku)
{
    int liczba = int.Parse(item);
    int ostatniaCyfra;
    int odbicie = 0;
    while (liczba > 0)
    {
        ostatniaCyfra = liczba % 10;
        odbicie = odbicie * 10 + ostatniaCyfra;

        liczba /= 10;
    }
    if (odbicie % 17 == 0)
        Console.WriteLine(odbicie);
}

Console.WriteLine("zadanie 4.2");
int najwLiczba = 0;
int najwRoznica = 0;
foreach (var item in liczbyZpliku)
{
    int liczba = int.Parse(item);
    int ostatniaCyfra;
    int odbicie = 0;
    int roznica = 0;
    while (liczba > 0)
    {
        ostatniaCyfra = liczba % 10;
        odbicie = odbicie * 10 + ostatniaCyfra;

        liczba /= 10;
    }

    liczba = int.Parse(item);
    roznica = liczba - odbicie;

    if (roznica < 0)
        roznica = roznica * (-1);

    if (roznica > najwLiczba)
    {
        najwRoznica = roznica;
        najwLiczba = liczba;
    }
}
Console.WriteLine($"{najwLiczba} {najwRoznica}");

Console.WriteLine("Zadanie 4.3");

int odbijanie(int liczba)
{
    int ostatniaCyfra;
    int odbicie = 0;
    while (liczba > 0)
    {
        ostatniaCyfra = liczba % 10;
        odbicie = odbicie * 10 + ostatniaCyfra;
        liczba /= 10;
    }
    return odbicie;
}

bool czyPierwsza(int liczba)
{
    int i = 2;
    while (liczba % i != 0)
    {
        i++;
    }
    if (i == liczba)
        return true;
    else
        return false;
}

foreach (var item in liczbyZpliku)
{
    int liczba = int.Parse(item);

    if (czyPierwsza(liczba) && czyPierwsza(odbijanie(liczba)))
    {
        Console.WriteLine(liczba);
    }
}