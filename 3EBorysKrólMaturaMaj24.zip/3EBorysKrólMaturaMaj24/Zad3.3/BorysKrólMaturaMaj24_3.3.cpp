﻿#include <iostream>
#include <fstream>

int nwd(int a, int b) {
    while (b != 0) {
        int r = a % b;
        a = b;
        b = r;
    }
    return a;
}

int nieparzystySkrot(int n) {
    int m = 0;
    int number = 1;

    while (n > 0) {
        int number2 = n % 10;
        if (number2 % 2 == 1) {
            m = m + number2 * number;
            number = number * 10;
        }
        n = n / 10;
    }

    return m;
}

int main() {
    std::ifstream dane("skrot2.txt");

    int liczba;
    while (dane >> liczba) {
        int skrot = nieparzystySkrot(liczba);
        if (skrot > 0 && nwd(liczba, skrot) == 7) {
            std::cout << liczba << '\n';
        }
    }

    return 0;
}