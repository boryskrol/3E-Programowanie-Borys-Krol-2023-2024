﻿#include <iostream>
#include <fstream>

int nieparzystySkrot(int n) {
    int m = 0;
    int number = 1;

    while (n > 0) {
        int number2 = n % 10;
        if (number2 % 2 == 1) {
            m = m + number2 * number;
            number = number * 10;
        }
        n = n / 10;
    }

    return m;
}

int main() {
    std::ifstream plik("skrot.txt");
    int liczba;
    int licznik = 0;
    int max = 0;

    while (plik >> liczba) {
        int skrot = nieparzystySkrot(liczba);
        if (skrot == 0) {
            licznik++;
            if (liczba > max) {
                max = liczba;
            }
        }
    }

    std::cout << licznik << '\n';
    std::cout << max << '\n';

    return 0;
}